"""GitHub repository compliance checks with audit reasoning."""

from github import Github, GithubException
from comply.aws.base import Finding

DOMAIN = "Source Code Security"


class GitHubRepoScanner:
    """Scans GitHub repositories for security and compliance."""

    def __init__(self, token: str, repos: list):
        self.gh = Github(token)
        self.repos = repos
        self.findings = []

    def _add(self, finding: Finding):
        self.findings.append(finding.to_dict())

    def scan(self) -> list:
        self.findings = []
        for repo_name in self.repos:
            try:
                repo = self.gh.get_repo(repo_name)
                self._check_branch_protection(repo, repo_name)
                self._check_security_policy(repo, repo_name)
                self._check_secrets_in_repo(repo, repo_name)
                self._check_dependabot(repo, repo_name)
                self._check_gitignore(repo, repo_name)
                self._check_license(repo, repo_name)
            except GithubException as e:
                self._add(Finding(
                    check_id="GH-ERR-001", title="Could not scan repository",
                    resource=repo_name, status=Finding.STATUS_WARN,
                    severity=Finding.SEVERITY_INFO,
                    description=f"Error scanning {repo_name}: {e}",
                    remediation="Verify the GitHub token and repo name.",
                    reasoning=f"Scanner could not access {repo_name}: {e}",
                    control_domain=DOMAIN))
            except Exception as e:
                self._add(Finding(
                    check_id="GH-ERR-002", title="Unexpected error",
                    resource=repo_name, status=Finding.STATUS_WARN,
                    severity=Finding.SEVERITY_INFO,
                    description=f"Unexpected error: {e}",
                    remediation="Check scanner logs.",
                    reasoning=f"Unexpected error scanning {repo_name}: {e}",
                    control_domain=DOMAIN))
        return self.findings

    def _check_branch_protection(self, repo, repo_name):
        default_branch = repo.default_branch
        try:
            branch = repo.get_branch(default_branch)
            protection = branch.get_protection()
            pr_required = False
            try:
                pr_required = protection.required_pull_request_reviews is not None
            except Exception:
                pass
            if pr_required:
                self._add(Finding(
                    check_id="GH-BP-001-PASS",
                    title="PR reviews required on default branch",
                    resource=repo_name, status=Finding.STATUS_PASS,
                    severity=Finding.SEVERITY_INFO,
                    description=f"Branch '{default_branch}' requires PR reviews before merging.",
                    remediation="No action required.",
                    reasoning=(
                        f"PASS: The default branch '{default_branch}' on {repo_name} requires pull request "
                        f"reviews. All code changes must be reviewed by at least one peer before merging, "
                        f"reducing the risk of introducing vulnerabilities or unauthorized changes. This "
                        f"satisfies SOC 2 CC8.1 (change management) and ISO 27001 A.14.2.2 (system change "
                        f"control procedures)."
                    ),
                    control_domain=DOMAIN,
                    frameworks={"SOC2": ["CC8.1"], "ISO27001": ["A.12.1.2", "A.14.2.2"]}))
            else:
                self._add(Finding(
                    check_id="GH-BP-001",
                    title="PR reviews not required on default branch",
                    resource=repo_name, status=Finding.STATUS_FAIL,
                    severity=Finding.SEVERITY_HIGH,
                    description=f"Branch '{default_branch}' does not require PR reviews.",
                    remediation="Enable 'Require pull request reviews before merging' with at least 1 approver.",
                    reasoning=(
                        f"FAIL: The default branch '{default_branch}' on {repo_name} does not require PR "
                        f"reviews. Any contributor with write access can push directly without peer review, "
                        f"bypassing change management controls. SOC 2 CC8.1 requires authorized and approved "
                        f"changes. ISO 27001 A.14.2.2 requires formal change control procedures."
                    ),
                    control_domain=DOMAIN,
                    frameworks={"SOC2": ["CC8.1"], "ISO27001": ["A.12.1.2", "A.14.2.2"]}))
            force_push = False
            try:
                if protection.allow_force_pushes:
                    force_push = protection.allow_force_pushes.enabled
            except Exception:
                pass
            if not force_push:
                self._add(Finding(
                    check_id="GH-BP-002-PASS",
                    title="Force pushes disabled on default branch",
                    resource=repo_name, status=Finding.STATUS_PASS,
                    severity=Finding.SEVERITY_INFO,
                    description=f"Force pushes are disabled on '{default_branch}'.",
                    remediation="No action required.",
                    reasoning=(
                        f"PASS: Force pushes are disabled on '{default_branch}' in {repo_name}. This "
                        f"preserves the audit trail by preventing commit history rewrites. SOC 2 CC8.1 and "
                        f"ISO 27001 A.12.1.2 require traceable change management."
                    ),
                    control_domain=DOMAIN,
                    frameworks={"SOC2": ["CC8.1"], "ISO27001": ["A.12.1.2"]}))
            else:
                self._add(Finding(
                    check_id="GH-BP-002",
                    title="Force pushes allowed on default branch",
                    resource=repo_name, status=Finding.STATUS_FAIL,
                    severity=Finding.SEVERITY_HIGH,
                    description=f"Force pushes are allowed on '{default_branch}'.",
                    remediation="Disable 'Allow force pushes' in branch protection settings.",
                    reasoning=(
                        f"FAIL: Force pushes are allowed on '{default_branch}' in {repo_name}. Any "
                        f"contributor can rewrite commit history, destroying the audit trail. A malicious "
                        f"actor could remove evidence of backdoors. SOC 2 CC8.1 and ISO 27001 A.18.1.3 "
                        f"require protection of records."
                    ),
                    control_domain=DOMAIN,
                    frameworks={"SOC2": ["CC8.1"], "ISO27001": ["A.12.1.2", "A.18.1.3"]}))
        except GithubException as e:
            if e.status == 404:
                self._add(Finding(
                    check_id="GH-BP-003",
                    title="No branch protection configured",
                    resource=repo_name, status=Finding.STATUS_FAIL,
                    severity=Finding.SEVERITY_CRITICAL,
                    description=f"No branch protection rules on '{default_branch}'.",
                    remediation="Configure branch protection: require PR reviews, status checks, restrict force pushes.",
                    reasoning=(
                        f"FAIL: No branch protection on '{default_branch}' in {repo_name}. CRITICAL — anyone "
                        f"with write access can push directly, force push to rewrite history, and delete the "
                        f"branch. No code review enforced. Violates SOC 2 CC8.1 (change management), CC1.1 "
                        f"(governance), ISO 27001 A.12.1.2 and A.14.2.2."
                    ),
                    control_domain=DOMAIN,
                    frameworks={"SOC2": ["CC8.1", "CC1.1"], "ISO27001": ["A.12.1.2", "A.14.2.2"]}))

    def _check_security_policy(self, repo, repo_name):
        found = False
        for path in ["SECURITY.md", "security.md", ".github/SECURITY.md"]:
            try:
                repo.get_contents(path)
                found = True
                break
            except GithubException:
                continue
        if found:
            self._add(Finding(check_id="GH-SEC-001-PASS", title="Security policy present",
                resource=repo_name, status=Finding.STATUS_PASS, severity=Finding.SEVERITY_INFO,
                description="Repository has a SECURITY.md vulnerability disclosure policy.",
                remediation="No action required.",
                reasoning=(f"PASS: {repo_name} has a SECURITY.md providing a vulnerability disclosure channel. "
                    f"SOC 2 CC7.4 requires incident response procedures. ISO 27001 A.16.1.2 requires "
                    f"mechanisms for reporting security events."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC7.4"], "ISO27001": ["A.16.1.2"]}))
        else:
            self._add(Finding(check_id="GH-SEC-001", title="No security policy (SECURITY.md)",
                resource=repo_name, status=Finding.STATUS_WARN, severity=Finding.SEVERITY_MEDIUM,
                description="Repository lacks a SECURITY.md vulnerability disclosure policy.",
                remediation="Add SECURITY.md with vulnerability reporting instructions.",
                reasoning=(f"WARNING: {repo_name} has no SECURITY.md. Researchers who find vulnerabilities "
                    f"have no guidance on responsible disclosure. SOC 2 CC7.4 and ISO 27001 A.16.1.2 "
                    f"require defined incident reporting channels."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC7.4"], "ISO27001": ["A.16.1.2"]}))

    def _check_secrets_in_repo(self, repo, repo_name):
        dangerous = [".env", ".env.local", ".env.production", "credentials.json", "service-account.json"]
        found = []
        for fname in dangerous:
            try:
                repo.get_contents(fname)
                found.append(fname)
            except GithubException:
                continue
        if found:
            files_str = ", ".join(found)
            self._add(Finding(check_id="GH-SEC-002", title="Secrets committed to repository",
                resource=repo_name, status=Finding.STATUS_FAIL, severity=Finding.SEVERITY_CRITICAL,
                description=f"Sensitive files in repo: {files_str}",
                remediation=f"Remove {files_str} with git rm --cached. Rotate all exposed credentials. Add to .gitignore.",
                reasoning=(f"FAIL: {repo_name} contains secret files: {files_str}. Credentials in version "
                    f"control are CRITICAL — they persist in git history even after deletion. SOC 2 CC6.1 "
                    f"requires logical access controls. ISO 27001 A.9.4.1 requires information access restriction."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC6.1", "CC6.7"], "ISO27001": ["A.9.4.1", "A.10.1.1"]}))
        else:
            self._add(Finding(check_id="GH-SEC-002-PASS", title="No secret files detected",
                resource=repo_name, status=Finding.STATUS_PASS, severity=Finding.SEVERITY_INFO,
                description="No .env, credentials.json, or similar files found.",
                remediation="No action required.",
                reasoning=(f"PASS: No common secret files found in {repo_name}. Secrets are managed outside "
                    f"the repository. Satisfies SOC 2 CC6.1 and ISO 27001 A.9.4.1."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC6.1"], "ISO27001": ["A.9.4.1"]}))

    def _check_dependabot(self, repo, repo_name):
        found = False
        for path in [".github/dependabot.yml", ".github/dependabot.yaml"]:
            try:
                repo.get_contents(path)
                found = True
                break
            except GithubException:
                continue
        if found:
            self._add(Finding(check_id="GH-DEP-001-PASS", title="Dependabot configured",
                resource=repo_name, status=Finding.STATUS_PASS, severity=Finding.SEVERITY_INFO,
                description="Dependabot is configured for automated dependency vulnerability scanning.",
                remediation="No action required.",
                reasoning=(f"PASS: {repo_name} has Dependabot configured for automated CVE detection in "
                    f"dependencies. SOC 2 CC7.1 requires vulnerability management. ISO 27001 A.12.6.1 "
                    f"requires management of technical vulnerabilities."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC7.1"], "ISO27001": ["A.12.6.1"]}))
        else:
            self._add(Finding(check_id="GH-DEP-001", title="No Dependabot configuration",
                resource=repo_name, status=Finding.STATUS_WARN, severity=Finding.SEVERITY_MEDIUM,
                description="No .github/dependabot.yml found.",
                remediation="Add .github/dependabot.yml to enable automated dependency scanning.",
                reasoning=(f"WARNING: {repo_name} has no Dependabot config. Known CVEs in dependencies may "
                    f"go undetected. SOC 2 CC7.1 and ISO 27001 A.12.6.1 require vulnerability management."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC7.1"], "ISO27001": ["A.12.6.1"]}))

    def _check_gitignore(self, repo, repo_name):
        try:
            content = repo.get_contents(".gitignore")
            text = content.decoded_content.decode("utf-8", errors="replace")
            important = [".env", "__pycache__", "*.pyc", "node_modules"]
            missing = [p for p in important if p not in text]
            if not missing:
                self._add(Finding(check_id="GH-GI-001-PASS", title=".gitignore covers critical patterns",
                    resource=repo_name, status=Finding.STATUS_PASS, severity=Finding.SEVERITY_INFO,
                    description=".gitignore includes .env, __pycache__, *.pyc, node_modules.",
                    remediation="No action required.",
                    reasoning=(f"PASS: {repo_name} .gitignore covers critical patterns, reducing risk of "
                        f"accidental secret commits. Supports SOC 2 CC6.1 and ISO 27001 A.9.4.1."),
                    control_domain=DOMAIN, frameworks={"SOC2": ["CC6.1"], "ISO27001": ["A.9.4.1"]}))
            else:
                self._add(Finding(check_id="GH-GI-001", title=".gitignore missing patterns",
                    resource=repo_name, status=Finding.STATUS_WARN, severity=Finding.SEVERITY_LOW,
                    description=f".gitignore missing: {", ".join(missing)}",
                    remediation=f"Add to .gitignore: {", ".join(missing)}",
                    reasoning=(f"WARNING: .gitignore in {repo_name} missing: {", ".join(missing)}."),
                    control_domain=DOMAIN, frameworks={"SOC2": ["CC6.1"]}))
        except GithubException:
            self._add(Finding(check_id="GH-GI-002", title="No .gitignore file",
                resource=repo_name, status=Finding.STATUS_WARN, severity=Finding.SEVERITY_MEDIUM,
                description="Repository has no .gitignore file.",
                remediation="Add a .gitignore for the project language/framework.",
                reasoning=(f"WARNING: {repo_name} has no .gitignore. Sensitive files may be committed "
                    f"accidentally. SOC 2 CC6.1 and ISO 27001 A.9.4.1 require access controls."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC6.1"], "ISO27001": ["A.9.4.1"]}))

    def _check_license(self, repo, repo_name):
        try:
            lic = repo.get_license()
            name = lic.license.name if lic and lic.license else "Detected"
            self._add(Finding(check_id="GH-LIC-001-PASS", title="License file present",
                resource=repo_name, status=Finding.STATUS_PASS, severity=Finding.SEVERITY_INFO,
                description=f"Repository has a license: {name}.",
                remediation="No action required.",
                reasoning=(f"PASS: {repo_name} has a license ({name}). Supports SOC 2 CC1.1 governance."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC1.1"]}))
        except GithubException:
            self._add(Finding(check_id="GH-LIC-001", title="No license file",
                resource=repo_name, status=Finding.STATUS_WARN, severity=Finding.SEVERITY_LOW,
                description="Repository has no license file.",
                remediation="Add a LICENSE file (MIT, Apache 2.0, etc.).",
                reasoning=(f"WARNING: {repo_name} has no license. SOC 2 CC1.1 recommends governance docs."),
                control_domain=DOMAIN, frameworks={"SOC2": ["CC1.1"]}))